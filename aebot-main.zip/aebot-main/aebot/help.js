
const help = (prefix, instagram, yt, name, pushname2, user, limitt) => { 
	return `

\`\`\`SUBSCRIBE😁\`\`\`
${yt}

\`\`\`Follow My Instagram\`\`\`
${instagram}

\`\`\`GROUP OFFICIAL\`\`\`
 https://chat.whatsapp.com/Kmi6sQqyxVN28ePYi2rmqb

\`\`\`HARAP BACA NOTE DIATAS SEBELUM\`\`\`
\`\`\`MENGGUNAKAN BOT\`\`\`

                  *USER* ${name}

   \`\`\`Hai\`\`\`👋 *${pushname2}*
   \`\`\`I am\`\`\` ${name}
   *Limit Kamu : ${limitt}*

  🚻 \`\`\`Total Pengguna:\`\`\` *${user.length} User*
  🏧 \`\`\`Total Donasi:\`\`\` *1%* 🙂


               *ABOUT* ${name}
🌀 *${prefix}request [Mau Req Fitur Apa?]*
🌀 *${prefix}report [lapor bug]*
🌀 *${prefix}info*
🌀 *${prefix}donasi*
🌀 *${prefix}owner*
🌀 *${prefix}speed*
🌀 *${prefix}daftar*
🌀 *${prefix}totaluser*
🌀 *${prefix}chatlist*
🌀 *${prefix}grouplist*
🌀 *${prefix}blocklist*
🌀 *${prefix}banlist*
🌀 *${prefix}bahasa*

              *MEDIA DOWNLOADER*
🗂 *${prefix}tiktokstalk [username]*
🗂 *${prefix}igstalk [username]*
🗂 *${prefix}insta [Link]*
🗂 *${prefix}instastory [username]*
🗂 *${prefix}ssweb [url]*
🗂 *${prefix}url2img [Url]*
🗂 *${prefix}tiktok*
🗂 *${prefix}fototiktok*
🗂 *${prefix}meme*
🗂 *${prefix}memeindo*
🗂 *${prefix}kbbi*
🗂 *${prefix}wait*
🗂 *${prefix}trendtwit*
🗂 *${prefix}google [berita terkini]*

               *CREATOR MENU* 
🔰 *${prefix}quotemaker [tx/wtrmk/tema]*
🔰 *${prefix}nulis [nama/kelas/text]*
🔰 *${prefix}trigger [reply image]*
🔰 *${prefix}rip [reply image]*
🔰 *${prefix}wasted [reply image]*
🔰 *${prefix}cphlogo [aebot/BOT]*
🔰 *${prefix}cglitch [aebot/BOT]*
🔰 *${prefix}cpubg [aebot/BOT]*
🔰 *${prefix}cml [miya/aebot]*
🔰 *${prefix}tahta [aebot]*
🔰 *${prefix}croman [aebot dan BOT]*
🔰 *${prefix}cthunder [aebot]*
🔰 *${prefix}cbpink [aebot]*
🔰 *${prefix}cmwolf [aebot]*
🔰 *${prefix}csky [aebot]*
🔰 *${prefix}cwooden [aebot]*
🔰 *${prefix}cflower [aebot]*
🔰 *${prefix}clove [aebot]*
🔰 *${prefix}ccrossfire [aebot]*
🔰 *${prefix}cnaruto [aebot]*
🔰 *${prefix}cparty [aebot]*
🔰 *${prefix}cshadow [aebot]*
🔰 *${prefix}cminion [aebot]*
🔰 *${prefix}cneon [aebot]*
🔰 *${prefix}cneon2 [aebot]*
🔰 *${prefix}cneongreen [aebot]*
🔰 *${prefix}c3d [aebot]*
🔰 *${prefix}csky [aebot]*
🔰 *${prefix}tts [id Haii]*
🔰 *${prefix}ttp [aebot]*
🔰 *${prefix}slide [aebot]*
🔰 *${prefix}stiker*
🔰 *${prefix}gifstiker*
🔰 *${prefix}toimg*
🔰 *${prefix}img2url*
🔰 *${prefix}nobg*
🔰 *${prefix}tomp3*
🔰 *${prefix}ocr*

               *GROUP ONLY* 
🌐 *${prefix}modeanime [On/Off]*
🌐 *${prefix}naruto*
🌐 *${prefix}minato*
🌐 *${prefix}boruto*
🌐 *${prefix}hinata*
🌐 *${prefix}sakura*
🌐 *${prefix}sasuke*
🌐 *${prefix}kaneki*
🌐 *${prefix}toukachan*
🌐 *${prefix}rize*
🌐 *${prefix}akira*
🌐 *${prefix}itori*
🌐 *${prefix}kurumi*
🌐 *${prefix}miku*
🌐 *${prefix}anime*
🌐 *${prefix}animecry*
🌐 *${prefix}neonime*
🌐 *${prefix}animekiss*
🌐 *${prefix}wink*
🌐 *${prefix}welcome [On/Off]*
🌐 *${prefix}grup [buka/tutup]*
🌐 *${prefix}antilink [on/off]*
🌐 *${prefix}ownergrup*
🌐 *${prefix}setpp*
🌐 *${prefix}infogc*
🌐 *${prefix}add*
🌐 *${prefix}kick*
🌐 *${prefix}promote*
🌐 *${prefix}demote*
🌐 *${prefix}setname*
🌐 *${prefix}setdesc*
🌐 *${prefix}linkgrup*
🌐 *${prefix}tagme*
🌐 *${prefix}hidetag*
🌐 *${prefix}tagall*
🌐 *${prefix}mentionall*
🌐 *${prefix}fitnah*
🌐 *${prefix}listadmin*
🌐 *${prefix}openanime*
🌐 *${prefix}edotense*

🔞 *${prefix}nsfw [On/Off]*
🔞 *${prefix}nsfwloli*
🔞 *${prefix}nsfwblowjob*
🔞 *${prefix}nsfwneko*
🔞 *${prefix}nsfwtrap*
🔞 *${prefix}hentai*
🔞 *${prefix}simih [On/Off]*
🔞 *${prefix}cersex*
🔞 *${prefix}xxx [japan]*
🔞 *${prefix}pornhub [stepMoms]*

               *OTHERS FUN & GAME*
🐶 *${prefix}anjing*
🐱 *${prefix}kucing*
🎲 *${prefix}testime*
🎲 *${prefix}hilih*
🎲 *${prefix}say*
🎲 *${prefix}apakah*
🎲 *${prefix}kapankah*
🎲 *${prefix}bisakah*
🎲 *${prefix}rate*
🎲 *${prefix}watak*
🎲 *${prefix}hobby*
🚨 *${prefix}infogempa*
🎲 *${prefix}infonomor*
🎲 *${prefix}quotes*
🎲 *${prefix}truth*
🎲 *${prefix}dare*
🎲 *${prefix}katabijak*
🎲 *${prefix}fakta*
🎲 *${prefix}darkjokes*
🎲 *${prefix}bucin*
🎲 *${prefix}pantun*
🎲 *${prefix}katacinta*
📺 *${prefix}jadwaltvnow*
🎲 *${prefix}hekerbucin*
🎲 *${prefix}katailham*
🗺 *${prefix}jarak [Pemalang/Jogja]*
🆎 *${prefix}translate [en/Apa kabar?]*
💑 *${prefix}pasangan [Aziz/Nita]*
👦 *${prefix}gantengcek [Aziz]*
👩 *${prefix}cantikcek [Nita]*
✅ *${prefix}artinama [Aziz]*
❎ *${prefix}persengay [Nur]*
💟 *${prefix}pbucin [Aziz]*
💱 *${prefix}bpfont [Aziz]*
🆎 *${prefix}textstyle [aebot]*
📺 *${prefix}jadwaltv [antv]*
🎼 *${prefix}lirik [melukis senja]*
🎹 *${prefix}chord [Melukis senja]*
🌏 *${prefix}wiki [Adolf Hitler]*
🌏 *${prefix}brainly [pertanyaan]*
🍛 *${prefix}resepmasakan [rawon]*
🌏 *${prefix}map [Pemalang]*
📽 *${prefix}film [Fast and Farious]*
🖼 *${prefix}pinterest [gambar kucing]*
🌤 *${prefix}infocuaca [Pemalang]*
🕙 *${prefix}jamdunia [Pemalang]*
💤 *${prefix}mimpi [Ular]*
📪 *${prefix}infoalamat [jalan Gt.Subroto]*
🎭 *${prefix}asupan*
🎭 *${prefix}tebakgambar*
🎭 *${prefix}caklontong*
🎭 *${prefix}family100*
🧮 *${prefix}kalkulator [13*12]*
🖼 *${prefix}wp [gunung]*
🕋 *${prefix}jadwalsholat [Pemalang]*
🕋 *${prefix}quran*
🕋 *${prefix}quransurah [1]*
🕋 *${prefix}tafsir [1/5]*

🗂 *${prefix}becrypt [string]*
🗂 *${prefix}encode64 [string]*
🗂 *${prefix}decode64 [encrypt]*
🗂 *${prefix}encode32 [string]*
🗂 *${prefix}decode32 [encrypt]*
🗂 *${prefix}encbinary [string]*
🗂 *${prefix}decbinary [encrypt]*
🗂 *${prefix}encoctal [string]*
🗂 *${prefix}decoctal [encrypt]*
🗂 *${prefix}hashidentifier [Encrypt Hash]*
🗂 *${prefix}dorking [dork]*
🗂 *${prefix}pastebin [teks]*
🗂 *${prefix}tinyurl [link]*
🗂 *${prefix}bitly [link]*

📩 *${prefix}spamcall [083xxxxxxxxx]*
📩 *${prefix}spamsms [083xxxxxxxx/jumlah]*
📩 *${prefix}spamgmail [alamat gmial]*

                *OWNER ONLY* 
⛔ *${prefix}addprem [mentioned]*
⛔ *${prefix}removeprem [mention]*
⛔ *${prefix}setppbot*
⛔ *${prefix}setreply*
⛔ *${prefix}bc*
⛔ *${prefix}bcgc*
⛔ *${prefix}ban*
⛔ *${prefix}unban*
⛔ *${prefix}block*
⛔ *${prefix}unblock*
⛔ *${prefix}clearall*
⛔ *${prefix}delete*
⛔ *${prefix}clone*
⛔ *${prefix}getses*
⛔ *${prefix}leave*

               *PREMIUM ONLY*
💵 *${prefix}playmp3 [menepi]*
💵 *${prefix}fb [link video]*
💵 *${prefix}snack [link snack video]*
💵 *${prefix}ytmp3 [link yt]*
💵 *${prefix}ytmp4 [link yt]*
💵 *${prefix}joox [Monolog Pamungkas]*
💵 *${prefix}smule [Link Video Smule]*


               *SUPPORT* ${name}

`
}
exports.help = help